import numpy as np

# Globals ----------------------------------------------------------------------
# Label number to name and color
INSTANCE_LABELS = {26: {'name': 'Character Line Segment', 'color': [0, 0, 142]},
                   24: {'name': 'Hole(Physical)', 'color': [220, 20, 60]},
                   25: {'name': 'Hole(Virtual)', 'color': [255,  0,  0]},
                   32: {'name': 'Physical Degradation', 'color': [0, 0, 230]},
                   33: {'name': 'Library Marker', 'color': [119, 11, 32]},
                   27: {'name': 'Character Component', 'color': [0, 0, 70]},
                   28: {'name': 'Decorator', 'color': [0, 60, 100]},
                   31: {'name': 'Page Boundry', 'color': [0, 80, 100]}}

# Label name to number
LABEL_DICT = {'Character Line Segment': 26, 'Hole(Physical)': 24, 'Physical Degradation': 32, 'Library Marker': 33,
              'Character Component': 27, 'Decorator': 28, 'Page Boundry': 31, 'Hole(Virtual)': 25}

# Array of keys
KEYS = np.array([[26000, 26999], [24000, 24999], [25000, 25999],
                 [32000, 32999], [33000, 33999], [27000, 27999],
                 [28000, 28999], [31000, 31999]])

